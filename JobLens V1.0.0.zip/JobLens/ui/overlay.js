window.JobLensUI = {

    render(offer){

        let overlay = document.getElementById("joblens-overlay");

        if(!overlay){

            overlay = document.createElement("div");

            overlay.id = "joblens-overlay";

            document.body.appendChild(overlay);

        }

        overlay.innerHTML = `
            <span id="jl-close">✕</span>

            <h2>${offer.title}</h2>

            <p class="joblens-company">${offer.company}</p>

            <p>${offer.location}</p>

            <hr>

            <strong>Compatibilidad</strong>

            <p>Calculando...</p>
        `;

        document.getElementById("jl-close").onclick = () => {

            overlay.remove();

        };

    }

};